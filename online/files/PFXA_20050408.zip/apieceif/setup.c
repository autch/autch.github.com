/*++

Copyright (c) 1997-1998  Microsoft Corporation

Module Name:

    RWBulk.c

Abstract:

    Console test app for BulkUsb.sys driver

Environment:

    user mode only

Notes:

  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
  PURPOSE.

  Copyright (c) 1997-1998 Microsoft Corporation.  All Rights Reserved.


Revision History:

	11/17/97: created

--*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include <time.h>
#include <setupapi.h>
#include <basetyps.h>

#include "usbdi.h"
#include "devioctl.h"


// functions

HANDLE
OpenOneDevice (
    IN       HDEVINFO                    HardwareDeviceInfo,
    IN       PSP_INTERFACE_DEVICE_DATA   DeviceInfoData,
	IN		 char *devName
    )
/*++
Routine Description:

    Given the HardwareDeviceInfo, representing a handle to the plug and
    play information, and deviceInfoData, representing a specific usb device,
    open that device and fill in all the relevant information in the given
    USB_DEVICE_DESCRIPTOR structure.

Arguments:

    HardwareDeviceInfo:  handle to info obtained from Pnp mgr via SetupDiGetClassDevs()
    DeviceInfoData:      ptr to info obtained via SetupDiEnumInterfaceDevice()

Return Value:

    return HANDLE if the open and initialization was successfull,
	else INVLAID_HANDLE_VALUE.

--*/
{
    PSP_INTERFACE_DEVICE_DETAIL_DATA     functionClassDeviceData = NULL;
    ULONG                                predictedLength = 0;
    ULONG                                requiredLength = 0;
	HANDLE								 hOut = INVALID_HANDLE_VALUE;

    //
    // allocate a function class device data structure to receive the
    // goods about this particular device.
    //
    SetupDiGetInterfaceDeviceDetail (
            HardwareDeviceInfo,
            DeviceInfoData,
            NULL, // probing so no output buffer yet
            0, // probing so output buffer length of zero
            &requiredLength,
            NULL); // not interested in the specific dev-node


    predictedLength = requiredLength;
    // sizeof (SP_FNCLASS_DEVICE_DATA) + 512;

    functionClassDeviceData = malloc (predictedLength);
    functionClassDeviceData->cbSize = sizeof (SP_INTERFACE_DEVICE_DETAIL_DATA);

    //
    // Retrieve the information from Plug and Play.
    //
    if (! SetupDiGetInterfaceDeviceDetail (
               HardwareDeviceInfo,
               DeviceInfoData,
               functionClassDeviceData,
               predictedLength,
               &requiredLength,
               NULL)) {
		free( functionClassDeviceData );
        return INVALID_HANDLE_VALUE;
    }

	strcpy( devName,functionClassDeviceData->DevicePath) ;
//	printf( "Attempting to open %s\n", devName );

    hOut = CreateFile (
                  functionClassDeviceData->DevicePath,
                  GENERIC_READ | GENERIC_WRITE,
                  FILE_SHARE_READ | FILE_SHARE_WRITE,
                  NULL, // no SECURITY_ATTRIBUTES structure
                  OPEN_EXISTING, // No special create flags
                  0, // No special attributes
                  NULL); // No template file

    if (INVALID_HANDLE_VALUE == hOut) {
//		printf( "FAILED to open %s\n", devName );
    }
	free( functionClassDeviceData );
	return hOut;
}



HANDLE OpenUsbDevice( LPGUID  pGuid, char *outNameBuf, int devno )
{
	HANDLE hOut = INVALID_HANDLE_VALUE;
	SP_INTERFACE_DEVICE_DATA deviceInfoData;
	HDEVINFO hardwareDeviceInfo;

	hardwareDeviceInfo = SetupDiGetClassDevs(
							pGuid,
							NULL,
							NULL,
							(DIGCF_PRESENT | DIGCF_INTERFACEDEVICE));

	deviceInfoData.cbSize = sizeof (SP_INTERFACE_DEVICE_DATA);

	if ( SetupDiEnumDeviceInterfaces(hardwareDeviceInfo,
										NULL,
										pGuid,
										devno,
										&deviceInfoData) ) {

		hOut = OpenOneDevice(hardwareDeviceInfo, &deviceInfoData, outNameBuf);
	}

	SetupDiDestroyDeviceInfoList(hardwareDeviceInfo);

	return hOut;
}



