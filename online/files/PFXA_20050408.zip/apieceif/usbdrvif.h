
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE TOOLS : pieceif.dll : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
// USB �]���R�A�� DLL
//
//  v1.00 2001.11.09 MIO.H
//  v1.07 2002.01.06 MIO.H
//


HANDLE usbOpen( int devno );
HANDLE usbOpenPipe( UCHAR pno );
void usbClosePipe( HANDLE h );
void usbClose( HANDLE h );
BOOL usbResetDevice( HANDLE h );
