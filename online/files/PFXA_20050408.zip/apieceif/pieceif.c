
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE TOOLS : pieceif.dll : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
// USB �]���R�A�� DLL
//
//  v1.00 2001.11.09 MIO.H
//  v1.04 2001.11.28 MIO.H	ver1.07�ȍ~�̓E�G�C�g���Ȃ���
//  v1.05 2001.11.29 MIO.H	�r������� Mutex ���g��
//  v1.06 2001.12.21 MIO.H	���������̃G���[�R�[�h(��d�N��)
//  v1.07 2002.01.06 MIO.H	������ڑ�
//  ????? 2002.01.26 Missing cat(Modify) / Rokuhara(Test) [Privately]
//                   ---v1.07 based 2MB/512KB Flash(SST) support version---


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include "usbdrvif.h"
#define INDLL
#include "pieceif.h"

//                 01234567890123456789
#define MUTEXNAME "_pieceif_dll_mutex_"

#define ismWait(n) SleepEx(n,TRUE)

static volatile DWORD donef;
static volatile DWORD dlen;
static volatile DWORD derr;

#if 0
VOID CALLBACK acc_done(
  DWORD dwErrorCode,                // �����R�[�h
  DWORD dwNumberOfBytesTransfered,  // �]���o�C�g��
  LPOVERLAPPED lpOverlapped         // I/O ��񂪂���
                                    // �\���̂ւ̃|�C���^
)
{
	donef = 1;
	derr = dwErrorCode;
	dlen = dwNumberOfBytesTransfered;
}
#endif


unsigned char _piece_version_info[32];
int _piece_version;

typedef struct tagUSBHANDLES {
	HANDLE hMutex;
	HANDLE hdev;
	HANDLE hrd;
	HANDLE hwt;
} USBHANDLES;

static USBHANDLES usbhandles[PIECE_MAX_DEVICES];
static USBHANDLES *curusb = usbhandles;

#define ismReadOpen() (curusb->hrd)
#define ismWriteOpen() (curusb->hwt)
#define ismCloseHandle(h)

int DLLAPI ismCmdW( const void *ptr1, unsigned len1, const void *ptr2, unsigned len2 )
{
	//OVERLAPPED ovl;
	int len3;
	HANDLE hWrite = ismWriteOpen();

	if (hWrite == INVALID_HANDLE_VALUE) return 1;

	WriteFile(hWrite, ptr1, len1, &len3, NULL);
	//donef = 0;
	//WriteFileEx(hWrite, ptr1, len1, &ovl, acc_done);
	//while ( !donef ) SleepEx(INFINITE, TRUE);

	if ( len2 ) {
 		WriteFile(hWrite, ptr2, len2, &len3, NULL);
		//donef = 0;
		//WriteFileEx(hWrite, ptr2, len2, &ovl, acc_done);
		//while ( !donef ) SleepEx(INFINITE, TRUE);
 	}
 	else if ( _piece_version < 0x107 ) {
 		ismWait( 15 );
 	}

	if(hWrite != INVALID_HANDLE_VALUE) ismCloseHandle(hWrite);

	return 0;
}

int DLLAPI ismCmdR( const void *ptr1, unsigned len1, void *ptr2, unsigned len2 )
{
	//OVERLAPPED ovl;
	int len3;

	//printf( "*Write %d(%d)\n", ((unsigned char *)ptr1)[0], len1 );
	{
	    HANDLE hWrite = ismWriteOpen();

		if (hWrite == INVALID_HANDLE_VALUE) return 1;

		WriteFile(hWrite, ptr1, len1, &len3, NULL);
		//donef = 0;
		//WriteFileEx(hWrite, ptr1, len1, &ovl, acc_done);
		//while ( !donef ) SleepEx(INFINITE, TRUE);

		if(hWrite != INVALID_HANDLE_VALUE) ismCloseHandle(hWrite);
	}

	//printf( "*Read\n" );
	{
		HANDLE hRead = ismReadOpen();

		if (hRead == INVALID_HANDLE_VALUE) return 1;

		ReadFile(hRead, ptr2, len2, &len3, NULL);
		//donef = 0;
		//ReadFileEx(hRead, ptr2, len2, &ovl, acc_done);
		//while ( !donef ) SleepEx(INFINITE, TRUE);

		dlen = len3;

		if(hRead != INVALID_HANDLE_VALUE) ismCloseHandle(hRead);
	}

	return 0;
}



int DLLAPI ismReadMem( unsigned char *pBuff, unsigned long adrs, unsigned len )
{
	unsigned char tmp[10];

	tmp[0] = 2;
	*(long *)(tmp+1) = adrs;
	*(long *)(tmp+5) = len;

	return ismCmdR(tmp,9,pBuff,len);
}


int DLLAPI ismWriteMem( const unsigned char *pBuff, unsigned long adrs, unsigned len )
{
	unsigned char tmp[10];

	tmp[0] = 3;
	*(long *)(tmp+1) = adrs;
	*(long *)(tmp+5) = len;

	return ismCmdW(tmp,9,pBuff,len);
}


int DLLAPI ismExec( unsigned long adrs )
{
	unsigned char tmp[8];

	tmp[0] = 1;
	if ( adrs & 1 ) tmp[0] = 8;
	*(long *)(tmp+1) = adrs;

	return ismCmdW(tmp,5,0,0);
}



int DLLAPI ismGetVersion( void *ptr, int renew )
{
	unsigned char tmp[4];
	int ver = PIECE_INVALID_VERSION;

	if ( renew ) {
		int retryc = 0;

		_piece_version = ver;

		while ( 1 ) {
			tmp[0] = 0;
			if ( ismCmdR(tmp,1,_piece_version_info,8) ) return _piece_version;

			if ( dlen == 8 ) break;

			printf( "donef=%d dlen=%d derr=%d ResetDevice!!\n", donef, dlen, derr );
			usbResetDevice( curusb->hdev );

			if ( ++retryc >= 3 ) return _piece_version;
		} 

		ver = *(unsigned short *)(_piece_version_info+4);

		if ( ver >= 21 ) {
			tmp[0] = 0;
			tmp[1] = ( *(short *)(_piece_version_info+4) >= 25 ? 32 : 24 );
			if ( ismCmdR(tmp,2,_piece_version_info,tmp[1]) ) return _piece_version;
		}

		_piece_version = ver;
	}

	if ( ptr ) {
		memcpy( ptr, _piece_version_info, 32 );
	}

	return _piece_version;
}


static void ismCloseHandles( USBHANDLES *pu )
{
	if ( pu->hrd != INVALID_HANDLE_VALUE ) {
		usbClosePipe( pu->hrd );
		pu->hrd = INVALID_HANDLE_VALUE;
	}

	if ( pu->hwt != INVALID_HANDLE_VALUE ) {
		usbClosePipe( pu->hwt );
		pu->hwt = INVALID_HANDLE_VALUE;
	}

	if ( pu->hdev != INVALID_HANDLE_VALUE ) {
		usbClose( pu->hdev );
		pu->hdev = INVALID_HANDLE_VALUE;
	}
}



//BOOL WINAPI HandlerRoutine( DWORD dwCtrlType )
//{
//	if ( dwCtrlType == CTRL_C_EVENT ) {
//		fprintf( stderr, "HandlerRoutine(%d)\n", dwCtrlType );
//		ismExit();
//	}
//	return FALSE;
//}

int DLLAPI ismInitEx( int devno, int waitn )
{
	USBHANDLES *pu;
	DWORD time0 = GetTickCount();

	if ( devno >= PIECE_MAX_DEVICES ) return ERR_PIECEIF_OVER_DEVICES;

	if ( waitn == PIECE_DEF_WAITN ) waitn = 500;

	pu = usbhandles + devno;

	curusb = pu;

	if ( pu->hMutex ) return 0;

	// ----------------------------------------------

	{
		char name[32];
		strcpy( name, MUTEXNAME );
		if ( devno ) {
			char *p = name + strlen( name );
			sprintf( p, "%d", devno );
		}
		pu->hMutex = CreateMutex( NULL, FALSE, name );
	}

	if ( !pu->hMutex ) {
		printf( "Mutex�쐬���s\n" );
		return 2;
	}

	if ( WaitForSingleObjectEx( pu->hMutex, waitn, FALSE ) != WAIT_OBJECT_0 ) {
		CloseHandle( pu->hMutex );
		printf( "��d�N��?\n" );
		pu->hMutex = NULL;
		return ERR_PIECEIF_ALREADY_RUNNING;
	}

	// ----------------------------------------------

	while ( 1 ) {
		pu->hdev = usbOpen(devno);

		if ( pu->hdev != INVALID_HANDLE_VALUE ) {
			int ver;

			pu->hrd = usbOpenPipe(0);
			pu->hwt = usbOpenPipe(1);

			ver = ismGetVersion( NULL, 1 );
			if ( ver != PIECE_INVALID_VERSION ) break;

			ismCloseHandles( pu );
		}
		//printf( "(%d,%d)", husb, GetLastError() );

		{
			DWORD time = GetTickCount() - time0;
			if ( time > (DWORD)waitn ) {
				return 1;
			}
		}

		Sleep(10);
	}

	return 0;
}


int DLLAPI ismInit( void )
{
	return ismInitEx( 0, PIECE_DEF_WAITN );
}

int DLLAPI ismExitEx( int devno )
{
	USBHANDLES *pu;

	if ( devno >= PIECE_MAX_DEVICES ) return ERR_PIECEIF_OVER_DEVICES;

	pu = usbhandles + devno;

	fprintf( stderr, "Exit USB#%d\n", devno );

	ismCloseHandles( pu );

	if ( pu->hMutex ) {
		ReleaseMutex( pu->hMutex );
		CloseHandle( pu->hMutex );
		pu->hMutex = NULL;
	}

	return 0;
}

int DLLAPI ismExit( void )
{
	int i, err = 0;

	for ( i = 0; i < PIECE_MAX_DEVICES; i++ ) {
		if ( usbhandles[i].hMutex ) err = ismExitEx( i );
	}

	return err;
}

int DLLAPI ismSelect( int devno )
{
	USBHANDLES *pu;

	if ( devno >= PIECE_MAX_DEVICES ) return ERR_PIECEIF_OVER_DEVICES;

	pu = usbhandles + devno;

	if ( !pu->hMutex ) return 1;

	curusb = pu;

	return 0;
}



int DLLAPI ismUCOpen( USBCOMS *pucs )
{
	unsigned char tmp[1];

	if ( _piece_version < 49 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 13;

	return ismCmdR(tmp,1,pucs,12+16);
}

int DLLAPI ismUCClose( void )
{
	unsigned char tmp[1];

	if ( _piece_version < 49 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 14;

	return ismCmdR(tmp,1,tmp,1);
}

int DLLAPI ismUCWrite( void *ptr, int len )
{
	unsigned char tmp[1];

	if ( _piece_version < 49 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 11;

	return ismCmdW(tmp,1,ptr,len);
}

int DLLAPI ismUCRead( void *ptr, int len )
{
	unsigned char tmp[1];

	if ( _piece_version < 49 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 10;

	return ismCmdR(tmp,1,ptr,len);
}

int DLLAPI ismUCGetStat( USBCOMS *pucs )
{
	unsigned char tmp[1];

	if ( _piece_version < 49 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 12;

	return ismCmdR(tmp,1,pucs,12);
}



int ismSetAppStat( int stat )
{
	unsigned char tmp[4];

	tmp[0] = 4;
	tmp[1] = stat;

	return ismCmdW(tmp,2,0,0);
}


int ismGetAppStat( int *ret )
{
	unsigned char tmp[4];

	tmp[0] = 5;

	if ( ismCmdR(tmp,1,tmp,2) ) return -1;

	*ret = *(short *)tmp;

	return 0;
}


int ismAppCtrl( long stat )
{
	if ( _piece_version >= 22 ) {

		if ( stat == 3 ) {
			if ( ismSetAppStat( stat ) ) return 1;
			stat = 0;
		}
		else if ( stat == 1 ) {
			if ( ismSetAppStat( stat ) ) return 1;
			stat = 2;
		}
		else {
			return 1;
		}
		{
			int c = 100;
			while ( c-- ) {
				int a;
				if ( ismGetAppStat( &a ) ) return 1;
				if ( a == stat ) return 0;
				ismWait( 20 );
			}
			printf( "Time Out\n" );
		}
	}
	else {
		if ( ismSetAppStat( stat ) ) return 1;
		ismWait( 20 );
		return 0;
	}

	return 1;
}


int ismAppPause( int pausef )
{
	unsigned char tmp[2];

	if ( _piece_version < 0x102 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 16;
	tmp[1] = pausef;

	//printf( "Pause %d\n", tmp[1] );

	return ismCmdW(tmp,2,0,0);
}


int ismLCDGetInfo( int *pstat, unsigned long *pbuff )
{
	unsigned char tmp[12];
	int err;

	if ( _piece_version < 0x102 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 17;

	//printf( "LCD Info " );

	err = ismCmdR(tmp,1,tmp,12);

	if ( !err ) {
		*pstat = tmp[0];
		*pbuff = *(unsigned long *)(tmp+8);
		//printf( "%d ", *pstat );
		//printf( "0x%x\n", *pbuff );
	}

	return err;
}


int DLLAPI ismHeapGetAdrs( unsigned long *padr )
{
	unsigned char tmp[1];

	if ( _piece_version < 0x103 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 18;

	return ismCmdR(tmp,1,padr,4);
}



