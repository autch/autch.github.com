
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE TOOLS : pieceif.dll : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
// USB �]���R�A�� DLL
//
//  v1.00 2001.11.09 MIO.H
//  v1.07 2002.01.06 MIO.H
//



// usbdrvif.c
//
// USB�f�o�C�X�ƃh���C�o���x���łh�e���܂��B
//
// 2001.11.04 MIO.H
//

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include <assert.h>
#include <tchar.h>

#include "usbdrvif.h"
#include "devioctl.h"
#include "bulkusr.h"

#define MAXPIPE 2


#if 0
// {AE284617-35D6-4c34-8ED5-55D9FF539C7B} for pcedrv.sys
DEFINE_GUID(GUID_CLASS_PIECE_DRIVER, 
0xae284617, 0x35d6, 0x4c34, 0x8e, 0xd5, 0x55, 0xd9, 0xff, 0x53, 0x9c, 0x7b);
#endif
// {6068EB61-98E7-4c98-9E20-1F068295909A}
DEFINE_GUID(GUID_CLASS_I82930_BULK, 
0x873fdf, 0x61a8, 0x11d1, 0xaa, 0x5e, 0x0, 0xc0, 0x4f, 0xb1, 0x72, 0x8b);

// {69910468-8802-11d3-ABC7-A756B2FDFB29} for UUSBD.SYS 
DEFINE_GUID(GUID_CLASS_UUSBD, 
0x69910468, 0x8802, 0x11d3, 0xab, 0xc7, 0xa7, 0x56, 0xb2, 0xfd, 0xfb, 0x29);



typedef struct tagUSBDEVDATA {
	LPGUID pGuid;
	LPCTSTR pipename;
} USBDEVDATA;

static USBDEVDATA usbdevdata[] = {
	{(LPGUID)&GUID_CLASS_PIECE_DRIVER, "%s\\PIPE%d"},
	{(LPGUID)&GUID_CLASS_I82930_BULK, "%s\\PIPE%d"},
	{(LPGUID)&GUID_CLASS_UUSBD,       "%s\\if000pipe%03d"},
};

static TCHAR devicename[MAX_PATH+50];
static LPCTSTR pipename;

// setup.c
HANDLE OpenUsbDevice(LPGUID pGuid, char *outNameBuf, int devno );



HANDLE usbOpen( int devno )
{
	int i;

	pipename = NULL;
	*devicename = 0;

	for ( i = 0; i < sizeof(usbdevdata)/sizeof(usbdevdata[0]); i++ ) {
		USBDEVDATA *pud = usbdevdata + i;
		HANDLE h_ctrl = OpenUsbDevice(pud->pGuid, devicename, devno);
//		printf( "%d %d\n", i, h_ctrl );
		if ( h_ctrl != INVALID_HANDLE_VALUE ) {
			pipename = pud->pipename;
//			printf( "%s\n", devicename );
			return h_ctrl;
		}
	}

	return INVALID_HANDLE_VALUE;
}


HANDLE usbOpenPipe(UCHAR pno)
{
	HANDLE h = INVALID_HANDLE_VALUE;

	if ( pipename ) {
		char name[MAX_PATH+100];
		_stprintf(name, pipename, devicename, pno);
		h = CreateFile(
			name,
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, // no SECURITY_ATTRIBUTES structure
			OPEN_EXISTING, // No special create flags
			0,
			NULL); // No template file
	}
	return h;
}


void usbClose(HANDLE husb)
{
	if ( husb != INVALID_HANDLE_VALUE ) CloseHandle( husb );
}


void usbClosePipe(HANDLE husb)
{
	if ( husb != INVALID_HANDLE_VALUE ) CloseHandle( husb );
}


BOOL usbResetDevice(HANDLE husb)
{
	DWORD size;
	BOOL err;
	err = DeviceIoControl(husb,
			IOCTL_BULKUSB_RESET_DEVICE,
			NULL,
			0,
			NULL,
			0,
			&size,
			NULL);
	return err;
}





