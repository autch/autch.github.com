
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE TOOLS : pieceif.dll : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
// USB �]���R�A�� DLL
//
//  v1.00 2001.11.09 MIO.H
//  v1.01 2001.11.10 MIO.H ismRTCSet �ǉ�
//  v1.02 2001.11.16 MIO.H ismLCDCaptureScreen �ǉ�
//  v1.06 2001.12.21 MIO.H �t�@�C�����̕s���`�F�b�N
//  ????? 2002.01.26 Missing cat(Modify) / Rokuhara(Test) [Privately]
//                   ---v1.06 based 2MB/512KB Flash(SST) support version---
//  v1.07 2003.08.05 Yui N. ismPFFSReadFirstSector(), ismPFFSDirEx() �ǉ�


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include "usbdrvif.h"
#define INDLL
#include "pieceif.h"
#define NOPCESPRINTF
#define __PCEKN__
#include "piece.h"

#define TBUFSIZ (32*1024)



extern unsigned char _piece_version_info[32];
extern int _piece_version;
int ismAppCtrl( long stat );
int ismAppPause( int pausef );
int ismLCDGetInfo( int *pstat, unsigned long *pbuff );


static pffsMASTERBLOCK msblk;
static unsigned long PFFSTOP;
static unsigned long PFFSEND;
static int MAXFAT2;

#define MSBLKADR PFFSTOP


static unsigned long read_mlong( unsigned char *mem )
{
	return (((((mem[0]<<8)+mem[1])<<8)+mem[2])<<8)+mem[3];
}

static unsigned short read_mshort( unsigned char *mem )
{
	return (mem[0]<<8)+mem[1];
}

static int check_fname( const char *p )
{
	int i;

	for ( i = 0; i < 2; i++ ) {
		int c = 0;
		char a;

		while ( 1 ) {
			a = *p++;
			if ( !(		// ���t�@�C�����ɋ�����镶���Z�b�g [0-9a-z_]
				( a >= '0' && a <= '9' ) ||
				( a >= 'a' && a <= 'z' ) ||
				( a == '_' )
				) ) break;
			c++;
		}

//		printf( "[%d]", c );

		if ( i == 0 ) {
			if ( c == 0 || c > 8 ) return 1;
			if ( !a ) return 0;
			if ( a != '.' ) return 2;
		}
		else {
			if ( c == 0 || c > 3 ) return 3;
			if ( !a ) return 0;
		}
	}

	return 4;
}





static int readfile_srf( FILE *fp )
{
	unsigned long last = -1L, ent = -1L;
	unsigned char tmp[64];
	unsigned long next;
	int m = 100;
	unsigned char *tbuff;

	fseek(fp, 0, SEEK_SET);

	if ( fread((char *)tmp, 1, 16, fp) != 16 ) return 2;

	if ( (read_mshort(tmp) | 8)!=0x000e ) return 3;

	printf( "\n" );

	next = read_mlong( tmp+8 );

	tbuff = malloc( TBUFSIZ );

	while ( next ) {
		unsigned long len;

		//printf( "[%x]", next);
		fseek(fp, next, SEEK_SET);

		if ( fread(tmp, 1, 44, fp) != 44 ) break;

		next = read_mlong( tmp );

		len = read_mlong( tmp+38 );

		if ( len ) {
			unsigned long adr = read_mlong( tmp+10 );
			unsigned long pos = read_mlong( tmp+34 );
			if ( pos ) {
				//printf( "  %06x %06x %06x\n", adr, len, pos );
				printf( "  %06x-%06x\n", adr, adr+len-1 );
				fseek(fp, pos, SEEK_SET);
				while ( len ) {
					unsigned long len2 = len;
					if ( len2 > TBUFSIZ ) len2 = TBUFSIZ;
					fread(tbuff,1,len2,fp);
					ismWriteMem(tbuff, adr, len2);
					adr += len2;
					len -= len2;
				}
			}
		}
	}

	free( tbuff );

	//if ( ent >= 0 ) printf( "Entry address = %06lx\n", ent );
	return 0;
}

int DLLAPI ismWriteSrfFile( const char *infname, int run )
{
	FILE *fp = fopen( infname, "rb" );
	int err = 1;

	if ( fp ) {
		if ( run ) ismAppStop();
		err = readfile_srf( fp );
		fclose( fp );
		if ( run ) ismAppStart();
	}

	return err;
}



int ismFlashErase( unsigned long adrs, int *ret )
{
	unsigned char tmp[5];

	if ( _piece_version < 31 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 8;
	*(unsigned long *)(tmp+1) = adrs;

	if ( ismCmdR(tmp,5,tmp,2) ) return 1;

	*ret = *(short *)tmp;

	printf( "FlashErase %x %x\n", adrs, *ret );

	return 0;
}


int ismFlashWrite( unsigned long dadrs, unsigned long sadrs, unsigned len, int *ret )
{
	unsigned char tmp[13];

	if ( _piece_version < 31 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 9;
	*(unsigned long *)(tmp+1) = dadrs;
	*(unsigned long *)(tmp+5) = sadrs;
	*(unsigned long *)(tmp+9) = len;

	if ( ismCmdR(tmp,13,tmp,2) ) return 1;

	*ret = *(short *)tmp;

	printf( "FlashWrite %x %x %x %x\n", dadrs, sadrs, len, *ret );

	return 0;
}






static int ffs_loaddir( void )
{
	{
		SYSTEMINFO *sip = (SYSTEMINFO *)_piece_version_info;
		PFFSTOP = (unsigned long)sip->pffs_top;
		PFFSEND = (unsigned long)sip->pffs_end;
		MAXFAT2 = ((PFFSEND - PFFSTOP) >> 12);
		if ( MAXFAT2 > MAXFAT ) MAXFAT2 = MAXFAT;
		//printf( "MAXFAT2=%d\n", MAXFAT2 );
	}
	return ismReadMem( (unsigned char *)&msblk, MSBLKADR, sizeof(msblk) ); 
}


static int flash_write( unsigned long adr, void *ptr, unsigned long len )
{
	int a;

	if ( ismWriteMem( (unsigned char *)ptr, 0x130000, len ) ) return 1;
	if ( ismFlashErase( adr, &a ) ) return 1;
	if ( a ) return a;
	if ( ismFlashWrite( adr, 0x130000, len, &a ) ) return 1;

	return a;
}


static int ffs_savedir( void )
{
	return flash_write( MSBLKADR, &msblk, sizeof(msblk) );
}

static DIRECTORY *ffs_srchdir( const char *name )
{
	DIRECTORY *pdir = msblk.dir;
	int i;

	for ( i = 0; i < MAXDIR; pdir++,i++ ) {
		unsigned char a = pdir->name[0];
		if ( a != 0 && a != 0xff ) {
			if ( !strcmp( name, pdir->name ) ) return pdir;
		}
	}

	return NULL;
}

static DIRECTORY *ffs_freedir( void )
{
	DIRECTORY *pdir = msblk.dir;
	int i;

	for ( i = 0; i < MAXDIR; pdir++,i++ ) {
		unsigned char a = pdir->name[0];
		if ( a == 0 || a == 0xff ) return pdir;
	}

	return NULL;
}


static void ffs_delete( DIRECTORY *pdir )
{
	int n = pdir->chain;
	FAT *pfat = msblk.fat;

	memset( pdir, 0xff, sizeof(*pdir) );

	while ( n < MAXFAT2 ) {
		int n1 = pfat[n].chain;
		pfat[n].chain = FAT_FREE;
		n = n1;
	}
}


static int ffs_read( DIRECTORY *pdir, FILE *fp )
{
	int n = pdir->chain;
	unsigned len = pdir->size;
	FAT *pfat = msblk.fat;
	char *tbuff = malloc( 4096 );

	while ( n < MAXFAT2 ) {
		int n1 = pfat[n].chain;
		unsigned len0 = len;
		if ( len0 > 4096 ) len0 = 4096;
		if ( ismReadMem( tbuff, PFFSTOP+n*0x1000, len0 ) ) break;
		if ( fwrite( tbuff, 1, len0, fp ) != len0 ) break;
		n = n1;
		len -= len0;
		if ( !len ) break;
	}

	free( tbuff );

	return len;
}


static int ffs_save( const char *name, unsigned char *pdata, int len )
{
		int i, n, len2, len3;
		unsigned short tbl[MAXFAT];
		DIRECTORY *pdir;
		FAT *pfat = msblk.fat;

		if ( !len ) return 1;

		len2 = len / 4096;
		len3 = len % 4096;
		if ( len3 ) len2++;

		pdir = ffs_srchdir( name );
		if ( pdir ) {
			ffs_delete( pdir );
		}

		pdir = ffs_freedir();

		if ( !pdir ) {
			printf( "�f�B���N�g��������܂���B\n" );
			return ERR_PIECEIF_PFFS_DIR_EMPTY;
		}

		// �z�u�̃X�g���e�W�[
		{
			i = 0;
			for ( n = 0; n < MAXFAT2; n++ ) {
				if ( pfat[n].chain == FAT_FREE ) {
					tbl[i++] = n;
					if ( i == len2 ) break;
				}
			}
			
			if ( i < len2 ) {
				printf( "�󂫂�����܂���B\n" );
				return ERR_PIECEIF_PFFS_EMPTY;
			}
		}

		memset( pdir, 0, sizeof(*pdir) );
		strncpy( pdir->name, name, sizeof(pdir->name)-1 );
		pdir->size = len;
		pdir->chain = tbl[0];

		i = 0;
		while ( len ) {
			n = tbl[i];
			len3 = len;
			if ( len3 >= 4096 ) len3 = 4096;
			if ( flash_write( PFFSTOP+n*0x1000, pdata, len3 ) ) break;
			pdata += len3;
			len -= len3;
			pfat[n].chain = ( i < len2-1 ) ? tbl[i+1] : FAT_END;
			i++;
		}

	return len ? 4 : 0;
}


int DLLAPI ismPFFSWrite( const char *fname, const char *infname )
{
	unsigned char *xbuff;
	int len;
	int err = 1;
	FILE *fp;

	if (_piece_version < 44) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	if (check_fname(fname)) return ERR_PIECEIF_PFFS_BAD_FAILENAME; // PFFS �̃t�@�C�������s��

	fp = fopen( infname, "rb" );
	if ( !fp ) return err;		// �t�@�C���I�[�v���Ɏ��s

	fseek( fp, 0, SEEK_END );
	len = ftell( fp );
	fseek( fp, 0, SEEK_SET );
	xbuff = malloc( len );
	fread( xbuff, 1, len, fp );
	fclose( fp );

	if ( !ismAppStop() ) {
		if ( !ffs_loaddir() ) {
			err = ffs_save( fname, xbuff, len );
			if ( !err ) {
				err = ffs_savedir();
			}
		}
		ismAppStart();
	}

	free( xbuff );

	return err;
}

int DLLAPI ismPFFSRead( const char *fname,  const char *outfname )
{
		DIRECTORY *pdir;
		int err = 1;

		if ( _piece_version < 44 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

		if ( !ffs_loaddir() ) {
			pdir = ffs_srchdir( fname );
			if ( pdir ) {
				FILE *fp = fopen( outfname, "wb" );
				if ( fp ) {
					printf( "reading '%s'", fname );
					err = ffs_read( pdir, fp );
					fclose( fp );
					printf( " done\n" );
				}
			}
		}

	return err;
}

int DLLAPI ismPFFSDelete( const char *fname )
{
	DIRECTORY *pdir;
	int err = 1;

	if ( _piece_version < 44 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	if ( !ismAppStop() ) {
		ffs_loaddir();
		pdir = ffs_srchdir( fname );
		if ( pdir ) {
			ffs_delete( pdir );
			err = ffs_savedir();
		}
		ismAppStart();
	}

	return err;
}


int DLLAPI ismPFFSInit( void )
{
	//                     012345678901234567890123
	static char sig[24] = "PFFS Master Block";
	int n = ( MSBLKADR - PFFSTOP ) / 4096;
	int err = 1;

	if ( _piece_version < 44 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	if ( !ffs_loaddir() ) {

		memset( &msblk, 0xff, sizeof(msblk) );
		memcpy( msblk.mark.signature, sig, sizeof(msblk.mark.signature) );
		msblk.mark.ptr = MSBLKADR+4;
		msblk.fat[n].chain = FAT_SYSTEM;
		for ( n = MAXFAT2; n < MAXFAT; n++ ) {
			msblk.fat[n].chain = FAT_INVALID;
		}
	
		if ( !ismAppStop() ) {
			err = ffs_savedir();
			ismAppStart();
		}
	}

	return err;
}


typedef struct tagCHARBUF {
	char *buf;
	char *end;
} CHARBUF;


static void putbuf( CHARBUF *pcb, char *in )
{
	int n = strlen( in );
	int len = pcb->end - pcb->buf;
	if ( n > len ) n = len;
	memcpy( pcb->buf, in, n );
	pcb->buf += n;
}

int DLLAPI ismPFFSDir( char *buff, unsigned len, int flag )
{
	CHARBUF cb = {buff, buff+len-1};

	if ( _piece_version < 44 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	if ( !ffs_loaddir() ) {
		DIRECTORY *pdir = msblk.dir;
		int i, c = 0;
		char tmp[256];

		for ( i = 0; i < MAXDIR; pdir++,i++ ) {
			unsigned char a = pdir->name[0];
			if ( a != 0 && a != 0xff ) {
				sprintf( tmp, "+%3d:%6d %s\n", i, pdir->size, pdir->name );
				putbuf( &cb, tmp );
			}
		}

		for ( i = 0; i < MAXFAT2; i++ ) {
			if ( msblk.fat[i].chain == FAT_FREE ) c++;
		}
		sprintf( tmp, "    %d sectors (%d bytes) free\n", c, c<<12 );
		putbuf( &cb, tmp );
	}

	*cb.buf = 0;

	return 0;
}



int DLLAPI ismAppStart( void )
{
	return ismAppCtrl( 0x01 );
}

int DLLAPI ismAppStop( void )
{
	return ismAppCtrl( 0x03 );
}


int DLLAPI ismRTCSet( int year, int mon, int day, int hour, int min, int sec )
{
	unsigned char tmp[10];
	PCETIME *ppt = (PCETIME *)(tmp+2);

	if ( _piece_version < 0x101 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	tmp[0] = 15;
	tmp[1] = 0;
	ppt->yy = year;
	ppt->mm = mon;
	ppt->dd = day;
	ppt->hh = hour;
	ppt->mi = min;
	ppt->ss = sec;
	ppt->s100 = 0;

	return ismCmdW(tmp,10,0,0);
}


#define ismWait(n) SleepEx(n,TRUE)

int DLLAPI ismLCDCaptureScreen( unsigned char *buff, int len )
{
	int err = 0;
	unsigned long vbuff;
	int i, f;

	if ( (err = ismAppPause( 1 )) != 0 ) return err;

	for ( i = 0; i < 100; i++ ) {
		if ( (err = ismLCDGetInfo( &f, &vbuff )) != 0 ) break;
		if ( f ) {
			err = ismReadMem( buff, vbuff, len );
			break;
		}
		ismWait( 20 );
		err = ERR_PIECEIF_TIMEOUT; // �^�C���A�E�g
	}

	ismAppPause( 0 );

	return err;
}

// �ȉ� Yui N. �̊g�� //////////////////////////////////////////////////////////

/**
  int ismPFFSReadFirstSector(LPSTR sFileName, BYTE *pBuffer, int nBytes)
	
	PFFS ��̃t�@�C�� sFilename �̐擪�Z�N�^�� nBytes �������ApBuffer �ɓǂݍ��ށB
	���������� pBuffer �̃T�C�Y�� nBytes �ȏ�Ȃ���΂Ȃ�Ȃ��B
*/
int DLLAPI ismPFFSReadFirstSector(const char *filename, unsigned char *buffer, int nBytes)
{
	DIRECTORY *pdir;
	int err = 1;

	if ( _piece_version < 44 ) return ERR_PIECEIF_ILL_VER; // BIOS�̃o�[�W�������Ⴄ

	if(!ffs_loaddir())
	{
		pdir = ffs_srchdir(filename);
		if(pdir)
		{
			int n = pdir->chain;
			return ismReadMem(buffer, PFFSTOP + n * 0x1000, nBytes);
		}
	}

	return err;
}

/**
	int ismPFFSDirEx(const int nAction, unsigned char *pszFileName, int *pnFileSize)

	PFFS �̊e��l���擾����B

	nAction == PFFSDIREX_COUNT	�ŁAPFFS ���̃t�@�C���̑�����Ԃ��B
	nAction == PFFSDIREX_FREE		�ŁA���� *�Z�N�^* ����Ԃ��B�o�C�g���ɒ����ɂ�
															12 �r�b�g���V�t�g����΂悢�B
	0 <= nAction < (PFFSDIREX_COUNT �ł̖߂�l)
															�ŁAPFFS �f�B���N�g���G���g���� n �Ԗڂ̃t�@�C������
															pszFileName �� pnFileSize �ɓ����B
															pszFileName �́APFFS �̎d�l�� 24 �o�C�g�ȏ�K�v�B

	�߂�l�F	nAction == PFFSDIREX_COUNT �Ȃ�΃t�@�C���̑������A
					nAction == PFFSDIREX_FREE �Ȃ�΂����Z�N�^�����A
					�����łȂ���΃G���[�R�[�h��Ԃ��B

	�G���[�R�[�h�F
				-3: P/ECE OS �̃o�[�W�������Ⴄ
				-2: PFFS �f�B���N�g���G���g���̓ǂݍ��݂Ɏ��s�����B�t���b�V�����S�H
				-1: ����ȃt�@�C���ԍ��͂Ȃ�
				 0: �G���[�Ȃ�
*/
int DLLAPI ismPFFSDirEx(const int nAction, unsigned char *pszFileName, int *pnFileSize)
{
	if(_piece_version < 44)	return ERR_PFFSDIREX_INVALID_VERSION;

	if(ffs_loaddir())	return ERR_PFFSDIREX_BAD_PFFS;

	switch(nAction)
	{
		case PFFSDIREX_COUNT:
		{
			DIRECTORY *pdir = msblk.dir;
			int i, files = 0;

			for(i = 0; i < MAXDIR; pdir++, i++)
			{
				unsigned char a = pdir->name[0];
				if(a != 0 && a != 0xff)
					files++;
			}
			return files;
		}
		case PFFSDIREX_FREE:
		{
			int i, sectors = 0;

			for(i = 0; i < MAXFAT2; i++)
				if(msblk.fat[i].chain == FAT_FREE)
					sectors++;

			return sectors;
		}
		default:
		{
			DIRECTORY *pdir = msblk.dir;
			int i, files = 0;

			for(i = 0; i < MAXDIR; pdir++, i++)
			{
				unsigned char a = pdir->name[0];
				if(a != 0 && a != 0xff)
				{
					if(files++ == nAction)
					{
						strncpy(pszFileName, pdir->name, 24);
						*pnFileSize = pdir->size;
						return 0;
					}
				}
			}
			return ERR_PFFSDIREX_NOT_FOUND;
		}
	}

	return 0;
}