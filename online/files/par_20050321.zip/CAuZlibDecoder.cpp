#include "CAuZlibDecoder.h"

VOID CAuZlibDecoder::Decode(HANDLE hInFile, HANDLE hOutFile)
{
	DWORD dwInputSize, dwDecodedSize, dwDummy;
	BYTE pHeader[37];

	ReadFile(hInFile, pHeader, 36, &dwDummy, NULL);

	dwInputSize = *(DWORD *)(pHeader + 16);
	dwDecodedSize = *(DWORD *)(pHeader + 28);

	BYTE *pInBuffer = new BYTE[dwInputSize], *pOutBuffer = new BYTE[dwDecodedSize];

	ReadFile(hInFile, pInBuffer, dwInputSize, &dwDummy, NULL);
	ZlibDecode(pInBuffer, dwInputSize, pOutBuffer, dwDecodedSize);
	WriteFile(hOutFile, pOutBuffer, dwDecodedSize, &dwDummy, NULL);
	delete [] pInBuffer;
	delete [] pOutBuffer;
}

VOID CAuZlibDecoder::Decode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize)
{
	DWORD dwDecodedSize, dwDummy;

	ReadFile(hInFile, &dwDecodedSize, sizeof(DWORD), &dwDummy, NULL);

	BYTE *pInBuffer = new BYTE[dwInputSize - 4], *pOutBuffer = new BYTE[dwDecodedSize];
	ReadFile(hInFile, pInBuffer, dwInputSize - 4, &dwDummy, NULL);
	ZlibDecode(pInBuffer, dwInputSize - 4, pOutBuffer, dwDecodedSize);
	WriteFile(hOutFile, pOutBuffer, dwDecodedSize, &dwDummy, NULL);
	delete [] pInBuffer;
	delete [] pOutBuffer;
}

DWORD CAuZlibDecoder::ZlibDecode(BYTE *inptr, DWORD size, BYTE *data, DWORD dwDecodedSize)
{
	z_stream z;																	/* ���C�u�����Ƃ��Ƃ肷�邽�߂̍\���� */
	int status;

	/* ���ׂẴ������Ǘ������C�u�����ɔC���� */
	z.zalloc = Z_NULL;
	z.zfree = Z_NULL;
	z.opaque = Z_NULL;

	/* ������ */
	z.next_in = Z_NULL;
	z.avail_in = 0;
	if(inflateInit(&z) != Z_OK)
		return (DWORD)-1;

	z.next_in = inptr;										/* ���̓|�C���^�����ɖ߂� */
	z.avail_in = size;										/* �f�[�^��ǂ� */
	z.next_out = data;										/* �o�̓|�C���^ */
	z.avail_out = dwDecodedSize;					/* �o�̓o�b�t�@�c�� */
	status = Z_OK;

	while(status != Z_STREAM_END)
	{
		status = inflate(&z, Z_NO_FLUSH);		/* �W�J */
		if(status == Z_STREAM_END)	break;	/* ���� */
		if(status != Z_OK)
			return (DWORD)-1;
	}

	/* ��n�� */
	if(inflateEnd(&z) != Z_OK)
		return (DWORD)-1;

	return dwDecodedSize - z.avail_out;
}

