
#ifndef CAULZSSDECODER_H
#define CAULZSSDECODER_H

#include "win32l.h"

#include "CAuFpkDecompressor.h"
#include "LZSSParams.h"

class CAuLZSSDecoder: public CAuFpkDecompressor
{
private:
	void hitodeLZSSDecode(BYTE *dst, BYTE *src, DWORD size);
public:
	VOID Decode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize);
};

#endif /* !CAULZSSDECODER_H */
