
#include "win32l.h"
#include "CAuCustomFpkDecoder.h"
#include "fpk.h"

CAuCustomFpkDecoder::CAuCustomFpkDecoder()
{
	m_hFile = INVALID_HANDLE_VALUE;
}

CAuCustomFpkDecoder::~CAuCustomFpkDecoder()
{
	if(m_hFile != INVALID_HANDLE_VALUE)
		CloseHandle(m_hFile);
}

BOOL CAuCustomFpkDecoder::GetFileInfo(LPSTR lpszFileNameInArchive, FPKENTRY *lpFileEntry)
{
	DWORD dwCount = 0, dwBytesRead = 0;
	FPKENTRY fpkEntry;

	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	SetFilePointer(m_hFile, sizeof(FPKHEADER), NULL, FILE_BEGIN);

	while(dwCount < m_FpkHeader.dwFilesAmount)
	{
		ReadFile(m_hFile, &fpkEntry, sizeof(FPKENTRY), &dwBytesRead, NULL);
		if(lstrcmp(lpszFileNameInArchive, fpkEntry.szFileName) == 0)
		{
			*lpFileEntry = fpkEntry;
			return TRUE;
		}
		dwCount++;
	}
	return FALSE;
}

BOOL CAuCustomFpkDecoder::GetFileInfo(DWORD dwFileIndex, FPKENTRY *lpFileEntry)
{
	DWORD dwCount = 0, dwBytesRead = 0;
	FPKENTRY fpkEntry;

	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	SetFilePointer(m_hFile, sizeof(FPKHEADER), NULL, FILE_BEGIN);

	while(dwCount < m_FpkHeader.dwFilesAmount)
	{
		ReadFile(m_hFile, &fpkEntry, sizeof(FPKENTRY), &dwBytesRead, NULL);
		if(dwCount == dwFileIndex)
		{
			*lpFileEntry = fpkEntry;
			return TRUE;
		}
		dwCount++;
	}
	return FALSE;
}
