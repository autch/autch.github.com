#ifndef FPKENCODE_H
#define FPKENCODE_H

#include "win32l.h"

#include "CAuFpkEncoder.h"
#include "CAuFpkCompressor.h"
#include "CAuLZSSEncoder.h"
#include "CAuZlibEncoder.h"
#include "fpkarc.h"

typedef enum tagCompressionMode{emRAW, emLZSS, emZLIB}	CompressionMode;

int RunEncoder(int argc, char *argv[], Actions mode);

#endif /* !FPKENCODE_H */
