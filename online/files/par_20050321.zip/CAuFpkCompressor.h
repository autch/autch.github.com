
#ifndef CAUFPKCOMPRESSOR_H
#define CAUFPKCOMPRESSOR_H

#include "win32l.h"
#include "fpk.h"

class CAuFpkCompressor
{
public:
	virtual VOID Encode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize, FPKENTRY *lpEntry) = 0;
};

#endif /* !CAUFPKCOMPRESSOR_H */
