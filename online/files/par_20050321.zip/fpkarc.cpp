
#ifdef BCC
#include <wildargs.h>
#endif

#include "win32l.h"
#include <stdio.h>
#include <stdlib.h>

#include "fpkDecode.h"
#include "fpkEncode.h"

#define USAGE(s)		{fputs(s, stderr); Usage(); return EXIT_FAILURE;}

int AnalyseParameters(int argc, char *argv[]);
void Usage();

int main(int argc, char *argv[])
{
	int r;

	r = AnalyseParameters(argc, argv);

	return r;
}

int AnalyseParameters(int argc, char *argv[])
{
	int r = EXIT_SUCCESS;
	Actions mode;

	// �����`�F�b�N�ƃ��[�h�ݒ�
	{
		if(argc < 3)
			USAGE("Too few arguments.\n\n");

		if(*(argv[1] + 1) != '\0')
			USAGE("Too long action specifier.\n\n");

		if((*argv[1] == 'l') || (*argv[1] == 'L'))
			mode = emLIST;
		else if((*argv[1] == 'e') || (*argv[1] == 'E'))
			mode = emDECODE;
		else if((*argv[1] == 'c') || (*argv[1] == 'C'))
			mode = emCREATE;
		else
			USAGE("Invalid action.\n\n");
	}

	switch(mode)
	{
		case emLIST:
		case emDECODE:
			r = RunDecoder(argc, argv, mode);
			break;
		case emCREATE:
			r = RunEncoder(argc, argv, mode);
			break;
	}

	return r;
}

void Usage()
{
	puts("par -- P/ECE fpk / par archiver w/ pva extractor\n"
			"\tCopyright(c) Yui N., 2003 - 2005.  All rights reserved.\n"
			"\tLZSS encoder/decoder by Hitode Yamatsuki.\n"
			"\tpva format by ZuraChu.\n"
			"\tzlib by Jean-loup Gailly and Mark Adler.\n"
			"\tCompiled on [" __DATE__ "  " __TIME__ "]\n"
			"\n"
			"Usage: par {l | e | c} [-cCtTrlz] fpkfile [file [...]]\n"
			"\n"
			"\tl\tList the content of archive.\n"
			"\te\tExtract file(s) from the archive.\n"
			"\tc\tCreate an archive and add files.\n"
			"\t-c\tStore filenames in lower case.\n"
			"\t-C\tDon't store filenames in lower case.\n"
      "\t-t\tTruncate filenames into 8.3 form.\n"
      "\t-T\tDon't truncate filenames.\n"
			"\t-r\tStore files normally.\n"
			"\t-l\tStore files LZSS-compressed.  Archive will be PAR format.\n"
			"\t-z\tStore files deflate-compressed.  Archive will be PAR format.\n"
			"\n"
			"Report bugs to yui@autch.net, http://www.autch.net/.\n"
	);
}
