
#ifndef CAUZLIBENCODER_H
#define CAUZLIBENCODER_H

#include "win32l.h"
#include "CAuFpkCompressor.h"

#include <zlib.h>

class CAuZlibEncoder: public CAuFpkCompressor
{
private:
	DWORD ZlibEncode(BYTE *inptr, DWORD size, BYTE *code, DWORD dwOutputSize);
public:
	VOID Encode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize, FPKENTRY *lpEntry);
};

#endif /* !CAUZLIBENCODER_H */
