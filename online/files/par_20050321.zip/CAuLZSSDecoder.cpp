
#include "CAuLZSSDecoder.h"

VOID CAuLZSSDecoder::Decode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize)
{
	DWORD dwDecodedSize, dwDummy;

	ReadFile(hInFile, &dwDecodedSize, sizeof(DWORD), &dwDummy, NULL);

	BYTE *pInBuffer = new BYTE[dwInputSize - 4], *pOutBuffer = new BYTE[dwDecodedSize];
	ReadFile(hInFile, pInBuffer, dwInputSize - 4, &dwDummy, NULL);
	hitodeLZSSDecode(pOutBuffer, pInBuffer, dwInputSize - 4);
	WriteFile(hOutFile, pOutBuffer, dwDecodedSize, &dwDummy, NULL);
	delete [] pInBuffer;
	delete [] pOutBuffer;
}

/*
	* reference: http://www.aw.wakwak.com/~hitode/piece/index.html#plz
	* author: Hitode Yamatsuki
	* for more information, see fpkarc.txt
*/

void CAuLZSSDecoder::hitodeLZSSDecode(BYTE *dst, BYTE *src, DWORD size)
{
	BYTE *base = src;

	while((DWORD)(src - base) < size)		// yui: fpk �̃p�f�B���O�o�C�g�̊֌W�ŃT�C�Y�`�F�b�N���K�v
	{
		int ct = 8, flag = *src++;

		do
		{
			if(flag & 0x80)
			{
				*dst++ = *src++;
			}
			else
			{
				unsigned int length, ptr = *src++;

				length = (ptr >> 4) + 3;
				if(!(ptr = ((ptr & 0xf) << 8) | (*src++)))
					return;
				{
					unsigned char *rp = dst - ptr;
					do
					{
						*dst++ = *rp++;
					}while(--length);
				}
			}
			flag <<= 1;
		}while(--ct);
	}
}
