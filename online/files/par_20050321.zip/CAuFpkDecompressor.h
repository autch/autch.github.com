
#ifndef CAUFPKDECOMPRESSOR_H
#define CAUFPKDECOMPRESSOR_H

#include "win32l.h"

class CAuFpkDecompressor
{
public:
	virtual VOID Decode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize) = 0;
};

#endif /* !CAUFPKDECOMPRESSOR_H */
