
#ifndef FPKARC_H
#define FPKARC_H

typedef enum tagActions{emUSAGE, emLIST, emDECODE, emCREATE}	Actions;

#endif /* !FPKARC_H */
