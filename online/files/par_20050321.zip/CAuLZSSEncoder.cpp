
#include "CAuLZSSEncoder.h"

VOID CAuLZSSEncoder::Encode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize, FPKENTRY *lpEntry)  /* ���k */
{
	BYTE *pInBuffer, *pOutBuffer;
	DWORD dwOutSize, dwDummy;

	WriteFile(hOutFile, &dwInputSize, sizeof(DWORD), &dwDummy, NULL);

	pInBuffer = new BYTE[dwInputSize];
	ReadFile(hInFile, pInBuffer, dwInputSize, &dwDummy, NULL);
	pOutBuffer = new BYTE[dwInputSize * (9 / 8) + 1024];		// �o�̓T�C�Y�����ς���

	dwOutSize = hitodeLZSSEncode(pOutBuffer, pInBuffer, dwInputSize);
	WriteFile(hOutFile, pOutBuffer, dwOutSize, &dwDummy, NULL);

	delete [] pInBuffer;
	delete [] pOutBuffer;

	lpEntry->dwSize = dwOutSize + 4;
	lpEntry->szFileName[15] = FPK_LZSS_COMPRESSION;
}

/*
	* reference: http://www.aw.wakwak.com/~hitode/piece/index.html#plz
	* author: Hitode Yamatsuki
	* for more information, see fpkarc.txt
*/

int CAuLZSSEncoder::SearchDic(int &ptr, BYTE *sp, BYTE *ep, BYTE *cp)
{
	BYTE *basep = cp - 1;
	int point = 0, max = 0, i;

	while(((basep - cp) > -DICTSIZE) && (basep >= sp))
	{
		for(i = 0; i < MAXMATCH; i++)
		{
			if(basep[i] != cp[i])
				break;
			if((i + cp) >= ep)
				break;
		}
		if(i == MAXMATCH)
		{
			ptr = basep - cp;
			return MAXMATCH;
		}
		if(i > max)
		{
			max = i;
			point = basep - cp;
		}
		basep--;
	}
	ptr = point;

	return max;
}

int CAuLZSSEncoder::hitodeLZSSEncode(BYTE *dst, BYTE *src, DWORD size)
{
	BYTE *sp = src, *dp = dst, *fp;
	int flagct, flag, ptr, length;

	fp = dp++;
	flagct = 7;
	flag = 0;
	while(sp < (src + size))
	{
		if(flagct < 0)
		{
			*fp = flag;
			fp = dp++;
			flagct = 7;
			flag = 0;
		}
		length = SearchDic(ptr, src, src + size, sp);
		if(length >= 3)
		{
			*dp++ = ((length - 3) << 4) | ((-ptr) >> 8);
			*dp++ = (-ptr) & 0xff;
			sp += length;
			flagct--;
		}
		else
		{
			*dp++ = *sp++;
			flag |= (1 << flagct);
			flagct--;
		}
	}
	if(flagct < 0)
	{
		*fp = flag;
		fp = dp++;
		flagct = 7;
		flag = 0;
	}
	*dp++ = 0;
	*dp++ = 0;
	*fp = flag;

	return dp - dst;
}
