
#include "win32l.h"
#include "CAuPvaDecoder.h"
#include "CAuZlibDecoder.h"

BOOL CAuPvaDecoder::OpenArchive(LPSTR lpszArchiveFileName)
{
	DWORD dwBytesRead = 0;

	m_hFile = CreateFile(lpszArchiveFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
												OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	ReadFile(m_hFile, &m_FpkHeader, sizeof(FPKHEADER), &dwBytesRead, NULL);
	if(m_FpkHeader.dwHeader != 'ANVP')
		return FALSE;

	return TRUE;
}

BOOL CAuPvaDecoder::ExtractFile(FPKENTRY *lpFileEntry, LPSTR lpszDiskFileName)
{
	HANDLE hOutputFile;

	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	SetFilePointer(m_hFile, lpFileEntry->dwOffset, NULL, FILE_BEGIN);

	hOutputFile = CreateFile(lpszDiskFileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
														FILE_ATTRIBUTE_NORMAL, NULL);
	if(hOutputFile == INVALID_HANDLE_VALUE)
		return FALSE;

	printf("stored ppack-compressed, inflating...");
	CAuZlibDecoder *zlibDecoder = new CAuZlibDecoder;
	zlibDecoder->Decode(m_hFile, hOutputFile);
	delete zlibDecoder;

	CloseHandle(hOutputFile);

	return TRUE;
}
