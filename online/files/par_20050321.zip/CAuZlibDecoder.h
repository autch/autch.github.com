
#ifndef CAUZLIBDECODER_H
#define CAUZLIBDECODER_H

#include "win32l.h"
#include "CAuFpkDecompressor.h"

#include <zlib.h>

class CAuZlibDecoder: public CAuFpkDecompressor
{
private:
	DWORD CAuZlibDecoder::ZlibDecode(BYTE *inptr, DWORD size, BYTE *data, DWORD dwDecodedSize);
public:
	VOID Decode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize);
	VOID Decode(HANDLE hInFile, HANDLE hOutFile);
};

#endif /* !CAUZLIBDECODER_H */
