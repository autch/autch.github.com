#include "fpkEncode.h"

#include <stdio.h>
#include <stdlib.h>

#include <string>
#include <vector>
#include <string.h>

typedef struct tagFile
{
	std::string sFileName;
	CompressionMode cMode;
	BOOL bLower;
  BOOL bTruncate83;
}File;

typedef std::vector<File>	Files;

int CreateArchive(CAuFpkEncoder *fpkEncoder, LPSTR lpszArchiveFileName, Files files, Actions mode)
{
	if(files.size() > 0)
	{
		printf("Creating archive: %s\n\n", lpszArchiveFileName);

		fpkEncoder->ReserveFileEntries(files.size());

		for(Files::iterator i = files.begin(); i != files.end(); i++)
		{
			CHAR szTemp[256], szShortName[256];
			strcpy(szTemp, i->sFileName.c_str());
			if(i->bTruncate83)
        GetShortPathName(szTemp, szShortName, 256);
      else
        lstrcpy(szShortName, szTemp);
			PathStripPath(szShortName);
			if(i->bLower)	strlwr(szShortName);

			printf("Freezing %-16s", szShortName);
			CAuFpkCompressor *pEncoder;
			switch(i->cMode)
			{
				case emRAW:
					pEncoder = NULL;
					break;
				case emLZSS:
					printf(" w/ LZSS compression");
					pEncoder = new CAuLZSSEncoder;
					break;
				case emZLIB:
					printf(" w/ deflation");
					pEncoder = new CAuZlibEncoder;
					break;
			}
			fpkEncoder->AddFile((CHAR *)i->sFileName.c_str(), szShortName, pEncoder);
			delete pEncoder;
			printf("... done.\n");
		}
		return EXIT_SUCCESS;
	}
	else
	{
		fputs("Nothing to do!\n", stderr);
		return EXIT_FAILURE;
	}
}

int RunEncoder(int argc, char *argv[], Actions mode)
{
	CAuFpkEncoder *fpkEncoder = new CAuFpkEncoder();
	int r = EXIT_SUCCESS;
	LPSTR lpszArchiveFileName = NULL;
	Files files;
	File file = {"", emRAW, FALSE, FALSE };

	for(int i = 2; i < argc; i++)
	{
		if(*argv[i] == '-')
		{
			switch(*(argv[i] + 1))
			{
				case 'c':	file.bLower = TRUE;		break;
				case 'C':	file.bLower = FALSE;	break;
				case 'r':	file.cMode = emRAW;		break;
				case 'l':	file.cMode = emLZSS;	break;
				case 'z':	file.cMode = emZLIB;	break;
        case 't': file.bTruncate83 = TRUE; break;        
        case 'T': file.bTruncate83 = FALSE; break;        
				default:
					fprintf(stderr, "invalid option - %c\n", *(argv[i] + 1));
			}
		}
		else
		{
			if(lpszArchiveFileName == NULL)
			{
				lpszArchiveFileName = argv[i];
				continue;
			}
			else
			{
				if(!PathFileExists(argv[i]))
				{
					fprintf(stderr, "Cannot locate file: %s, skipping.\n", argv[i]);
					continue;
				}
				file.sFileName = argv[i];
				files.push_back(file);
			}
		}
	}
	if(lpszArchiveFileName == NULL)
	{
		fputs("Archive file name must be specified.\n", stderr);
		return EXIT_FAILURE;
	}
	if(fpkEncoder->OpenArchive(lpszArchiveFileName) == TRUE)
	{
		switch(mode)
		{
			case emCREATE:
				r = CreateArchive(fpkEncoder, lpszArchiveFileName, files, mode);
				break;
		}
	}
	else
	{
		fprintf(stderr, "Cannot open archive: %s\n", lpszArchiveFileName);
		r = EXIT_FAILURE;
	}

	delete fpkEncoder;

	return r;
}
