
#include "CAuFpkEncoder.h"

CAuFpkEncoder::CAuFpkEncoder()
{
	m_hFile = INVALID_HANDLE_VALUE;

	m_FpkHeader.dwHeader = 0x4650414b;		// "FPAK"
	m_FpkHeader.dwFilesAmount = 0;
	m_dwFileIndex = 0;
	m_dwCompressedFileExists = FALSE;
}

CAuFpkEncoder::~CAuFpkEncoder()
{
	if(m_hFile != INVALID_HANDLE_VALUE)
	{
		if(m_dwCompressedFileExists)
		{
			SetFilePointer(m_hFile, 0, NULL, FILE_BEGIN);
			m_FpkHeader.dwHeader = 0x50415243;		// "PARC"
			DWORD dwBytesWritten;
			WriteFile(m_hFile, &m_FpkHeader, sizeof(FPKHEADER), &dwBytesWritten, NULL);
		}
		CloseHandle(m_hFile);
	}
}

BOOL CAuFpkEncoder::OpenArchive(LPSTR lpszArchiveFileName)
{
	m_hFile = CreateFile(lpszArchiveFileName, GENERIC_WRITE, 0, NULL,
												CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	return TRUE;
}

VOID CAuFpkEncoder::ReserveFileEntries(DWORD dwFilesAmount)
{
	DWORD dwBytesWritten;
	FPKENTRY fpkEntry;

	m_FpkHeader.dwFilesAmount = dwFilesAmount;
	WriteFile(m_hFile, &m_FpkHeader, sizeof(FPKHEADER), &dwBytesWritten, NULL);

	ZeroMemory(&fpkEntry, sizeof(FPKENTRY));
	for(DWORD i = 0; i < dwFilesAmount; i++)
		WriteFile(m_hFile, &fpkEntry, sizeof(FPKENTRY), &dwBytesWritten, NULL);
}

DWORD CAuFpkEncoder::RoundUpFourBytes()
{
	DWORD dwBytesWritten = 0;
	DWORD dwCurrentPos = SetFilePointer(m_hFile, 0, NULL, FILE_CURRENT);
	DWORD temp = 0;

	if(dwCurrentPos % 4)
		WriteFile(m_hFile, &temp, ((dwCurrentPos + 4) - (dwCurrentPos % 4)) - dwCurrentPos, &dwBytesWritten, NULL);
	return dwBytesWritten;
}

VOID CAuFpkEncoder::UpdateFileEntry(DWORD dwFileIndex, FPKENTRY *lpFpkEntry)
{
	DWORD dwBytesWritten = 0;

	SetFilePointer(m_hFile, sizeof(FPKHEADER) + sizeof(FPKENTRY) * dwFileIndex, NULL, FILE_BEGIN);
	WriteFile(m_hFile, lpFpkEntry, sizeof(FPKENTRY), &dwBytesWritten, NULL);
}

DWORD CAuFpkEncoder::PrepareForWritingNextFile()
{
	return SetFilePointer(m_hFile, 0, NULL, FILE_END);
}

BOOL CAuFpkEncoder::AddFile(LPSTR lpszLocalFileName, LPSTR lpszFileNameInArchive, CAuFpkCompressor *lpEncoder)
{
	HANDLE hFile;
	FPKENTRY fpkEntry;

	hFile = CreateFile(lpszLocalFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
												OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	ZeroMemory(&fpkEntry, sizeof(FPKENTRY));
	fpkEntry.dwOffset = PrepareForWritingNextFile();
	strncpy(fpkEntry.szFileName, lpszFileNameInArchive, 14);

	if(lpEncoder == NULL)
	{
		DWORD dwBytesRead, dwBytesWritten;

		fpkEntry.dwSize = GetFileSize(hFile, NULL);
		BYTE *pBuffer = new BYTE[fpkEntry.dwSize];
		ReadFile(hFile, pBuffer, fpkEntry.dwSize, &dwBytesRead, NULL);
		WriteFile(m_hFile, pBuffer, fpkEntry.dwSize, &dwBytesWritten, NULL);
		fpkEntry.szFileName[15] = 0;
		delete [] pBuffer;
	}
	else
	{
		DWORD dwSize = GetFileSize(hFile, NULL);
		lpEncoder->Encode(hFile, m_hFile, dwSize, &fpkEntry);

		m_dwCompressedFileExists = TRUE;
	}
	CloseHandle(hFile);

	RoundUpFourBytes();
	UpdateFileEntry(m_dwFileIndex++, &fpkEntry);

	return TRUE;
}
