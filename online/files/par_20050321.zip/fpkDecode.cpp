#include "fpkDecode.h"

#include <stdio.h>
#include <stdlib.h>

void ListArchive(CAuCustomFpkDecoder *fpkDecoder, LPSTR lpszArchiveFileName)
{
	FPKENTRY fpkEntry;

	printf("Listing archive: %s\n", lpszArchiveFileName);
	puts("--------------------------------------------------------------------------");
	for(DWORD i = 0; i < fpkDecoder->GetFileAmount(); i++)
	{
		if(fpkDecoder->GetFileInfo(i, &fpkEntry) == TRUE)
		{
			CHAR cChar;
			if((BYTE)fpkEntry.szFileName[15] == FPK_LZSS_COMPRESSION)
				cChar = 'L';
			else if((BYTE)fpkEntry.szFileName[15] == FPK_ZLIB_COMPRESSION)
				cChar = 'Z';
			else
				cChar = ' ';
			
			printf("%10d: %-16s\toffset:0x%08x\tsize:%10d%c\n", i,
				fpkEntry.szFileName, fpkEntry.dwOffset, fpkEntry.dwSize, cChar);
		}
	}
	puts("--------------------------------------------------------------------------");
	printf("%10d files.\n", fpkDecoder->GetFileAmount());
}

void ExtractAllFiles(CAuCustomFpkDecoder *fpkDecoder)
{
	FPKENTRY fpkEntry;

	for(DWORD i = 0; i < fpkDecoder->GetFileAmount(); i++)
	{
		fpkDecoder->GetFileInfo(i, &fpkEntry);
		printf("Extracting %-16s...", fpkEntry.szFileName);
		fpkDecoder->ExtractFile(&fpkEntry, fpkEntry.szFileName);
		printf("done.\n");
	}
}

void ExtractAFile(CAuCustomFpkDecoder *fpkDecoder, LPSTR lpszTargetFileName)
{
	FPKENTRY fpkEntry;

	if(fpkDecoder->GetFileInfo(lpszTargetFileName, &fpkEntry) == TRUE)
	{
		printf("Extracting %-16s...", fpkEntry.szFileName);
		fpkDecoder->ExtractFile(&fpkEntry, fpkEntry.szFileName);
		printf("done.\n");
	}
	else
		fprintf(stderr, "%s: No such file in the archive.\n", lpszTargetFileName);
}


int RunDecoder(int argc, char *argv[], Actions mode)
{
	CAuCustomFpkDecoder *fpkDecoder;
	int r = EXIT_SUCCESS;
	LPSTR lpszArchiveFileName = argv[2];

	if(lstrcmp(strlwr(strrchr(lpszArchiveFileName, '.')) + 1, "pva") == 0)
		fpkDecoder = new CAuPvaDecoder;
	else
		fpkDecoder= new CAuFpkDecoder;

	if(fpkDecoder->OpenArchive(lpszArchiveFileName) == TRUE)
	{
		switch(mode)
		{
			case emLIST:
			{
				if(argc > 3)
					fputs("Warning: 'l' command always lists all of files.\n", stderr);
				ListArchive(fpkDecoder, lpszArchiveFileName);
				break;
			}
			case emDECODE:
			{
				printf("Extracting from archive: %s\n\n", lpszArchiveFileName);
				if(argc == 3)
					ExtractAllFiles(fpkDecoder);
				else
					for(int i = 3; i < argc; i++)
						ExtractAFile(fpkDecoder, argv[i]);
			}
		}
	}
	else
	{
		fprintf(stderr, "Cannot open archive: %s\n", lpszArchiveFileName);
		r = EXIT_FAILURE;
	}
	delete fpkDecoder;

	return r;
}
