//////////////////////////////////////////////////////////
// fpk.cpp -- P/ECE fpk format archive decoder
// By Yui N., 2003.
//////////////////////////////////////////////////////////

#include "win32l.h"
#include "CAuFpkDecoder.h"
#include "CAuLZSSDecoder.h"
#include "CAuZlibDecoder.h"

BOOL CAuFpkDecoder::OpenArchive(LPSTR lpszArchiveFileName)
{
	DWORD dwBytesRead = 0;

	m_hFile = CreateFile(lpszArchiveFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
												OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	ReadFile(m_hFile, &m_FpkHeader, sizeof(FPKHEADER), &dwBytesRead, NULL);
	if(m_FpkHeader.dwHeader != 0x4650414b
			&& m_FpkHeader.dwHeader != 0x50415243)		// 'FPAK' 'PARC'
		return FALSE;

	return TRUE;
}

BOOL CAuFpkDecoder::ExtractFile(FPKENTRY *lpFileEntry, LPSTR lpszDiskFileName)
{
	HANDLE hOutputFile;

	if(m_hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	SetFilePointer(m_hFile, lpFileEntry->dwOffset, NULL, FILE_BEGIN);

	hOutputFile = CreateFile(lpszDiskFileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
														FILE_ATTRIBUTE_NORMAL, NULL);
	if(hOutputFile == INVALID_HANDLE_VALUE)
		return FALSE;

	{
		switch((BYTE)(lpFileEntry->szFileName[15]))
		{
			case FPK_LZSS_COMPRESSION:
			{
				printf("stored LZSS-compressed, decoding...");
				CAuLZSSDecoder *lzssDecoder = new CAuLZSSDecoder;
				lzssDecoder->Decode(m_hFile, hOutputFile, lpFileEntry->dwSize);
				delete lzssDecoder;
				break;
			}
			case FPK_ZLIB_COMPRESSION:
			{
				printf("stored deflated, inflating...");
				CAuZlibDecoder *zlibDecoder = new CAuZlibDecoder;
				zlibDecoder->Decode(m_hFile, hOutputFile, lpFileEntry->dwSize);
				delete zlibDecoder;
				break;
			}
			case FPK_NO_COMPRESSION:
			{
				BYTE *pBuffer = new BYTE[lpFileEntry->dwSize];
				if(pBuffer == NULL)
				{
					CloseHandle(hOutputFile);
					return FALSE;
				}
				DWORD dwBytesRead = 0;

				ReadFile(m_hFile, pBuffer, lpFileEntry->dwSize, &dwBytesRead, NULL);
				WriteFile(hOutputFile, pBuffer, lpFileEntry->dwSize, &dwBytesRead, NULL);
				delete [] pBuffer;
			}
		}
	}

	CloseHandle(hOutputFile);

	return TRUE;
}
