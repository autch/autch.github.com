
#ifndef CAULZSSENCODER_H
#define CAULZSSENCODER_H

#include "win32l.h"
#include "CAuFpkEncoder.h"
#include "LZSSParams.h"
#include "CAuFpkCompressor.h"

class CAuLZSSEncoder: public CAuFpkCompressor
{
private:
	int hitodeLZSSEncode(BYTE *dst, BYTE *src, DWORD size);
	int SearchDic(int &ptr, BYTE *sp, BYTE *ep, BYTE *cp);
public:
	VOID Encode(HANDLE hInFile, HANDLE hOutFile, DWORD dwInputSize, FPKENTRY *lpEntry);
};

#endif /* !CAULZSSENCODER_H */
