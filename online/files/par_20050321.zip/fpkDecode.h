
#ifndef FPKDECODE_H
#define FPKDECODE_H

#include "win32l.h"

#include "CAuCustomFpkDecoder.h"
#include "CAuFpkDecoder.h"
#include "CAuPvaDecoder.h"
#include "fpkarc.h"

void ListArchive(CAuCustomFpkDecoder *fpkDecoder, LPSTR lpszArchiveFileName);
void ExtractAllFiles(CAuCustomFpkDecoder *fpkDecoder);
void ExtractAFile(CAuCustomFpkDecoder *fpkDecoder, LPSTR lpszTargetFileName);
int RunDecoder(int argc, char *argv[], Actions mode);

#endif /* !FPKDECODE_H */
