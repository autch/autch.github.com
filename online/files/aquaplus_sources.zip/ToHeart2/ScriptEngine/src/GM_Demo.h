
#ifndef	DEMO_H_
#define DEMO_H_

extern void DEM_RenewSetp( void );

extern int	DEM_System( void );
extern void DEM_Draw( void *dest );

#endif//