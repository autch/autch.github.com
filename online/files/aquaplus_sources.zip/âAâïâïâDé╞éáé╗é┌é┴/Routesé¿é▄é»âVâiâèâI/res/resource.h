//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Routes_mini.rc
//
#define IDI_WINAVG                      101
#define IDR_MAINMENU                    102
#define ID_SUBMENU                      103
#define IDD_ABOUTDIALOG                 130
#define IDD_INFODIALOG                  131
#define IDD_CONFIGDIALOG                132
#define IDD_CONFIG1                     133
#define IDD_CONFIG2                     134
#define IDC_LINKCURSOR                  135
#define IDR_ACCELERATOR                 136
#define IDC_TAB1                        1001
#define IDC_CONFIGTAB                   1001
#define IDC_CFGUPDATE                   1002
#define IDC_EDIT1                       1003
#define IDC_MSGSPEED                    1004
#define IDC_MSGSPEED2                   1005
#define IDC_AUTOMSGSPEED                1005
#define IDC_SLIDER1                     1008
#define IDC_SLIDERBGM                   1008
#define IDC_IPADDRESS1                  1009
#define IDC_SLIDERVOICE                 1010
#define IDC_WWW                         1010
#define IDC_SLIDERSE                    1011
#define IDC_SKIPENABLE                  1014
#define IDC_SKIPEFFECT                  1015
#define IDC_VSELECT1                    1020
#define IDC_VSELECT2                    1021
#define IDC_VSELECT3                    1022
#define IDC_VSELECT4                    1023
#define IDC_VCHECK1                     1024
#define IDC_VCHECK2                     1025
#define IDC_VCHECK3                     1026
#define IDC_VCHECK4                     1027
#define IDC_VCHECK5                     1028
#define IDC_VCHECK6                     1029
#define IDC_VCHECK7                     1030
#define IDC_VCHECK8                     1031
#define IDC_VCHECK9                     1032
#define IDC_VCHECK10                    1033
#define IDC_VCHECK11                    1034
#define IDC_VOICEHMAN                   1035
#define IDC_VOICEREPEAT                 1036
#define ID_CONFIG                       40001
#define ID_MYAPP_EXIT                   40002
#define ID_DISPFULL                     40003
#define ID_DISPWINDOW                   40004
#define ID_VER                          40005
#define ID_INFO                         40006
#define ID_UPDATE                       40007
#define ID_LOADEXEC                     40008
#define ID_SAVEEXEC                     40009
#define ID_AUTOREAD                     40010
#define ID_READSKIP                     40011
#define ID_BACKSELECT                   40012
#define ID_BACKTITLE                    40013
#define ID_DISPCHANGE                   40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
