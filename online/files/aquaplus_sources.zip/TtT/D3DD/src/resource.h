//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDFLASH                         3
#define IDR_ACCELERATOR1                101
#define IDR_MENU2                       103
#define IDD_DIALOG_D3D_SETTING          104
#define IDR_MENU1                       104
#define IDD_DIALOG10                    108
#define IDD_DIALOG8                     109
#define IDI_ICON1                       111
#define IDD_DIALOG_VERSION              112
#define IDD_DIALOG1                     113
#define IDC_EDIT1                       1000
#define IDC_LIST2                       1001
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_CHECK1                      1004
#define IDC_CHECK2                      1005
#define IDC_SLIDER1                     1005
#define IDC_CHECK3                      1006
#define IDC_SLIDER2                     1006
#define IDC_CHECK4                      1007
#define IDC_SLIDER3                     1007
#define IDC_CHECK5                      1008
#define IDC_TEST                        1008
#define IDC_TEST2                       1009
#define IDC_CHECK6                      1009
#define IDC_CHECK_SE                    1010
#define IDC_CHECK_VOICE                 1011
#define IDC_CHECK_BGM                   1012
#define IDC_CHECK_ERO_VOICE             1013
#define ID_END                          40001
#define ID_FULL_MODE                    40002
#define ID_SAMPLE2                      40003
#define ID_WINDOW_MODE                  40004
#define ID_END2                         40005
#define ID_SKIP_READ                    40009
#define ID_SKIP_NOREAD                  40010
#define ID_TEXT_CUT                     40011
#define ID_TEXT_HIGH                    40012
#define ID_TEXT_NORMAL                  40013
#define ID_TEXT_LOW                     40014
#define ID_EFFECT_CUT                   40015
#define ID_EFFECT_HIGH                  40016
#define ID_EFFECT_NORMAL                40017
#define ID_EFFECT_LOW                   40018
#define ID_SOUND                        40023
#define ID_VER                          40025
#define ID_INFO                         40026
#define ID_LEAFHP                       40027
#define ID_MOV1                         40029
#define ID_MOV2                         40030
#define ID_MOV3                         40031
#define ID_MENU_MODE                    40032
#define ID_AUTO_RET                     40034
#define ID_WAIT_MODE                    40035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40037
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
