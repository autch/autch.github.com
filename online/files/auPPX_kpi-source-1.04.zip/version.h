
#ifndef AUPPX_KPI_VERSION
#define AUPPX_KPI_VERSION		((1 << 8) | 4)			// 1.04
#endif /* !AUPIECE_KPI_VERSION */
