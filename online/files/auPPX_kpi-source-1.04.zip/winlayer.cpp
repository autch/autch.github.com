#include "win32l.h"
#include "kmp_pi.h"
#include "CAuPPXDecoder.h"

extern "C"
{

HKMP WINAPI kpiOpen(const char *cszFileName, SOUNDINFO *pInfo)
{
	CAuPPXDecoder *pDecoder;

	if(pInfo == NULL)	return NULL;

	pDecoder = new CAuPPXDecoder;
	if(pDecoder == NULL)	return NULL;

	if(pDecoder->Open((LPSTR)cszFileName, pInfo))
		return (HKMP)pDecoder;
	else
	{
		pDecoder->Close();
		delete pDecoder;
		return NULL;
	}
}

void WINAPI kpiClose(HKMP hKMP)
{
	if(hKMP == NULL) return;

	CAuPPXDecoder *pDecoder = (CAuPPXDecoder *)hKMP;
	delete pDecoder;
}

DWORD WINAPI kpiRender(HKMP hKMP, BYTE* Buffer, DWORD dwSize)
{
	if(hKMP == NULL) return 0;

	CAuPPXDecoder *pDecoder = (CAuPPXDecoder *)hKMP;
	return pDecoder->Render(Buffer, dwSize);
}

DWORD WINAPI kpiSetPosition(HKMP hKMP, DWORD dwPos)
{
	if(hKMP == NULL) return 0;

	CAuPPXDecoder *pDecoder = (CAuPPXDecoder *)hKMP;
	return pDecoder->SetPosition(dwPos);
}

};
