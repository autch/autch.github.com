
#include "CAuPPXDecoder.h"

CAuPPXDecoder::CAuPPXDecoder()
{
	m_hPPXFile = NULL;
	::ZeroMemory(&m_ppxHeader, sizeof(PPXHEADER));
	::ZeroMemory(&m_Info, sizeof(SOUNDINFO));
}

CAuPPXDecoder::~CAuPPXDecoder()
{
	Close();
}

BOOL CAuPPXDecoder::Open(LPSTR lpszFileName, SOUNDINFO *pInfo)
{
	if(m_hPPXFile != NULL)	return FALSE;

	if(lpszFileName == NULL || pInfo == NULL)	return FALSE;

	m_hPPXFile = ::CreateFile(lpszFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
													FILE_ATTRIBUTE_NORMAL, NULL);
	if(m_hPPXFile == INVALID_HANDLE_VALUE)
		return FALSE;

	DWORD dwBytesRead;

	::ReadFile(m_hPPXFile, &m_ppxHeader, sizeof(PPXHEADER), &dwBytesRead, NULL);

	if(m_ppxHeader.dwSignature == 0x5050434d)		// 'PPCM'
	{
		::ZeroMemory(pInfo, sizeof(SOUNDINFO));
		::ZeroMemory(&m_Info, sizeof(SOUNDINFO));

		pInfo->dwChannels = 1;
		pInfo->dwSeekable = 1;

		if((m_ppxHeader.bType & (PW_TYPE_16BITPCM | PW_TYPE_4BITADPCM)) == 0)		// PW_TYPE_8BITPCM
			pInfo->dwBitsPerSample = 8;
		else
			pInfo->dwBitsPerSample = 16;

		if(m_ppxHeader.bType & PW_TYPE_VR)
			pInfo->dwSamplesPerSec = m_ppxHeader.wReserved;
		else
			pInfo->dwSamplesPerSec = 16000;

		// dwChannels == 1 �Ȃ̂Ń`���l�����͍l���̕K�v�Ȃ�
		if(m_ppxHeader.bType & PW_TYPE_4BITADPCM)
		{
			// ���ό`������ double �̃L���X�g��s�v��
			pInfo->dwLength = (m_ppxHeader.dwSize * 2) / (pInfo->dwSamplesPerSec / 1000);
			pInfo->dwUnitRender = 1024;			// �K��
		}
		else
		{
			pInfo->dwLength = m_ppxHeader.dwSize / (pInfo->dwBitsPerSample >> 3) / (pInfo->dwSamplesPerSec / 1000);
			pInfo->dwUnitRender = pInfo->dwBitsPerSample >> 3;
		}

		// �����̍��ڂ����������Čv�Z����̂͑�ςȂ̂Ŏ��O�ł������Ƃɂ���
		::CopyMemory(&m_Info, pInfo, sizeof(SOUNDINFO));
	}
	else
	{
		Close();
		return FALSE;
	}

	m_nDelta = 16;	m_nPcm = 0;

	return TRUE;
}

VOID CAuPPXDecoder::Close()
{
	if(m_hPPXFile != NULL && m_hPPXFile != INVALID_HANDLE_VALUE)
	{
		::CloseHandle(m_hPPXFile);
		m_hPPXFile = NULL;
	}
}

DWORD CAuPPXDecoder::Render(BYTE *pBuffer, DWORD dwSize)
{
	DWORD dwBytesRead;

	if(m_ppxHeader.bType & PW_TYPE_4BITADPCM)
	{
		DWORD dwBytesToRead, dwResult;

		dwBytesToRead = dwSize >> 2;
		if(pBuffer != NULL)
		{
			BYTE *pInput = new BYTE[dwBytesToRead];
			::ReadFile(m_hPPXFile, pInput, dwBytesToRead, &dwBytesRead, NULL);
			dwResult = ppxADPCMDecode((signed short *)pBuffer, pInput, dwBytesRead);
			delete [] pInput;
		}
		else
		{
			::SetFilePointer(m_hPPXFile, dwBytesToRead, NULL, FILE_CURRENT);
			dwResult = dwBytesToRead;
		}

		return dwResult;
	}
	else
	{
		::ReadFile(m_hPPXFile, pBuffer, dwSize, &dwBytesRead, NULL);
		return dwBytesRead;
	}
}

DWORD CAuPPXDecoder::SetPosition(DWORD dwPos)
{
	DWORD dwResult;
	
	if(m_ppxHeader.bType & PW_TYPE_4BITADPCM)
	{
		DWORD dwCurrent = ::SetFilePointer(m_hPPXFile, 0, NULL, FILE_CURRENT) - sizeof(PPXHEADER);
		DWORD dwSeekTo, dwSamplesToSeek, dwBytesRead;

		dwSamplesToSeek = dwPos * (m_Info.dwSamplesPerSec / 1000);
		dwSeekTo = dwSamplesToSeek >> 2;

		if(dwSeekTo == dwCurrent) return dwPos;
		if(dwSeekTo < dwCurrent)
		{
			::SetFilePointer(m_hPPXFile, sizeof(PPXHEADER), NULL, FILE_BEGIN);
			m_nDelta = 16;	m_nPcm = 0;
			BYTE *pBuffer = new BYTE[dwSeekTo];
			{
				::ReadFile(m_hPPXFile, pBuffer, dwSeekTo, &dwBytesRead, NULL);
				dwResult = ppxFastForward(pBuffer, dwSeekTo);
			}
			delete [] pBuffer;
		}
		else
		{
			DWORD dwBytesToRead = dwSeekTo - dwCurrent;
			BYTE *pBuffer = new BYTE[dwBytesToRead];
			{
				::ReadFile(m_hPPXFile, pBuffer, dwBytesToRead, &dwBytesRead, NULL);
				dwResult = ppxFastForward(pBuffer, dwBytesToRead) + dwCurrent;
			}
			delete [] pBuffer;
		}
	}
	else
	{
		DWORD dwSeekTo, dwResult, dwSamplesToSeek;

		dwSamplesToSeek = dwPos * (m_Info.dwSamplesPerSec / 1000);
		dwSeekTo = dwSamplesToSeek * (m_Info.dwBitsPerSample >> 3);
		dwResult = ::SetFilePointer(m_hPPXFile, sizeof(PPXHEADER) + dwSeekTo, NULL, FILE_BEGIN) - sizeof(PPXHEADER);
	}
	return dwResult / (m_Info.dwBitsPerSample >> 3) / (m_Info.dwSamplesPerSec / 1000);
}

// PIECE TOOLS : adpcv : Ver 0.90
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
// Coded by Katsumasa Tsuneyoshi
DWORD CAuPPXDecoder::ppxADPCMDecode(signed short *wave, BYTE *adp, DWORD size)
{
	DWORD dwOutputSize = 0;		// yui: size, in bytes, of the output data
	int delta = m_nDelta, pcm = m_nPcm;

	for(DWORD i = 0; i < size; i++)
	{
		int h, l;

		h = *adp++;
		l = h & 0x0f;	h >>= 4;

		pcm += delta * (h - 8);
		delta = (delta * dct[h]) >> 8;
		//*wave++ = pcm & 0xffff;
		*wave = pcm & 0xffff;
		if(pcm > 32767)	*wave = (signed short)32767;
		if(pcm < -32768)	*wave = (signed short)-32768;
		wave++;

		pcm += delta * (l - 8);
		delta = (delta * dct[l]) >> 8;
		//*wave++ = pcm & 0xffff;
		*wave = pcm & 0xffff;
		if(pcm > 32767)	*wave = (signed short)32767;
		if(pcm < -32768)	*wave = (signed short)-32768;
		wave++;

		dwOutputSize += 4;
	}

	m_nDelta = delta;
	m_nPcm = pcm;
	
	return dwOutputSize;
}

DWORD CAuPPXDecoder::ppxFastForward(BYTE *adp, DWORD size)
{
	DWORD dwOutputSize = 0;		// yui: size, in bytes, of the output data
	int delta = m_nDelta, pcm = m_nPcm;

	for(DWORD i = 0; i < size; i++)
	{
		int h, l;

		h = *adp++;
		l = h & 0x0f;	h >>= 4;

		pcm += delta * (h - 8);
		delta = (delta * dct[h]) >> 8;

		pcm += delta * (l - 8);
		delta = (delta * dct[l]) >> 8;

		dwOutputSize += 4;
	}

	m_nDelta = delta;
	m_nPcm = pcm;
	
	return dwOutputSize;
}
