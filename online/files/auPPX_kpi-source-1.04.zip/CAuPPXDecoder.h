
#ifndef CAUPPXDECODER_H
#define CAUPPXDECODER_H

#include "win32l.h"
#include "kmp_pi.h"
#include "ppx.h"

const static short dct[16] =
{
	233, 549, 453, 375, 310, 233, 233, 233,
	233, 233, 233, 233, 310, 375, 453, 549
};

class CAuPPXDecoder
{
private:
	HANDLE		m_hPPXFile;
	PPXHEADER	m_ppxHeader;
	SOUNDINFO	m_Info;
	int m_nDelta, m_nPcm;

	DWORD ppxADPCMDecode(signed short *wave, BYTE *adp, DWORD size);
	DWORD ppxFastForward(BYTE *adp, DWORD size);

public:
	CAuPPXDecoder();
	~CAuPPXDecoder();

	BOOL Open(LPSTR lpszFileName, SOUNDINFO *pInfo);
	VOID Close();

	DWORD Render(BYTE *pBuffer, DWORD dwSize);
	DWORD SetPosition(DWORD dwPos);
};

#endif /* !CAUPPXDECODER_H */
