#include "win32l.h"
#include "kmp_pi.h"
#include "version.h"
#include "winlayer.h"

extern "C"
{

/* DLL �p�� main() */
BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(static_cast<HMODULE>(hModule));
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}

/* �B��̃G�N�X�|�[�g�֐� */
KMPMODULE* WINAPI kmp_GetTestModule()
{
	static const char *Exts[] = {".ppd", ".ppg", ".ppx", NULL};

	static KMPMODULE kpiInfoBlock =
	{
		KMPMODULE_VERSION,				// DWORD dwVersion;
		AUPPX_KPI_VERSION,			// DWORD dwPluginVersion;
		"Copyright (c) 2001 - 2003, AQUAPLUS Co., Ltd. / OeRSTED, Inc. / Yui N. all rights reserved.  ",
															// const char	*pszCopyright;
		"P/ECE PCM decoder plugin for KbMedia Player",
															// const char	*pszDescription;
		Exts,											// const char	**ppszSupportExts;
		1,												// DWORD dwReentrant;
		NULL,											// void (WINAPI *Init)(void);
		NULL,											// void (WINAPI *Deinit)(void);
		kpiOpen,									// HKMP (WINAPI *Open)(const char *cszFileName, SOUNDINFO *pInfo);
		NULL,											// HKMP (WINAPI *OpenFromBuffer)(const BYTE *Buffer, DWORD dwSize, SOUNDINFO *pInfo);
		kpiClose,									// void (WINAPI *Close)(HKMP hKMP);
		kpiRender,								// DWORD (WINAPI *Render)(HKMP hKMP, BYTE* Buffer, DWORD dwSize);
		kpiSetPosition						// DWORD (WINAPI *SetPosition)(HKMP hKMP, DWORD dwPos);
	};
	return &kpiInfoBlock;
}

};		// extern "C"

