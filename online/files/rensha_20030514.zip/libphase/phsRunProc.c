#include "libphase.h"

void phsRunProc(int cnt)
{
	if(phsProc != NULL)
		phsProc(cnt);
}
