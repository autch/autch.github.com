#define LIBPHASE_DECLARE_GLOBALS
#include "libphase.h"

volatile phsProcedure				*phsProcs;
volatile phsProcedure				phsProc;
volatile phsChangeCallback	phsOnChanged;
