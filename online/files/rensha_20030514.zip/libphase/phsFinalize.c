#include "libphase.h"

void phsFinalize()
{
	free(phsProcs);
}
