#include "libphase.h"

void phsChange(int NewPhase)
{
	phsProc = phsProcs[NewPhase];
	if(phsOnChanged != NULL)	phsOnChanged(NewPhase);
}
