#include "libphase.h"

void phsInitialize(int MaxPhases)
{
	phsProcs = malloc(sizeof(phsProcedure) * MaxPhases);
	memset(phsProcs, (phsProcedure)NULL, MaxPhases);
	phsSetChangeCallback(NULL);
}
