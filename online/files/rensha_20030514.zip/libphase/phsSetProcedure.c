#include "libphase.h"

void phsSetProcedure(int PhaseNum, phsProcedure PhaseProcedure)
{
	phsProcs[PhaseNum] = PhaseProcedure;
}
