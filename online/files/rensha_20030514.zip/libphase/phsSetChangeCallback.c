#include "libphase.h"

void phsSetChangeCallback(phsChangeCallback pProc)
{
	phsOnChanged = pProc;
}
