/*
	* �A�˃Q�[
	* by Yui N., 2003.
*/

#include <piece.h>
#include <stdlib.h>
#include "libphase.h"

static unsigned char vScreen[128 * 88];
static unsigned char DrawFlag;
int errno;

///////////////////////////////////////////////////////////////////////////////

int CountdownStart = 0;
int KeyCount, Average;
int TrialSeconds = 20;

// ����
#define MAX_SCENES	5
typedef enum
{
	emNotStarted = 0,
	emCountingDown,
	emStarted,
	emSummary,
	emExit
}SCENENUM;

void spcNotStarted(int cnt);
void spcCountingDown(int cnt);
void spcExit(int cnt);
void spcStarted(int cnt);
void spcSummary(int cnt);
void OnPhaseChange(int PhaseNum);

void Cls()
{
	memset(vScreen, 0, 128 * 88);
	DrawFlag = 1;
}

void Refresh()
{
	if(DrawFlag)
	{
		pceLCDTrans();
		DrawFlag = 0;
	}
}

void PreparePhaseProcedure()
{
	phsInitialize(MAX_SCENES);
	phsSetChangeCallback(OnPhaseChange);
	phsSetProcedure(emNotStarted, spcNotStarted);
	phsSetProcedure(emCountingDown, spcCountingDown);
	phsSetProcedure(emExit, spcExit);
	phsSetProcedure(emStarted, spcStarted);
	phsSetProcedure(emSummary, spcSummary);
}

void OnPhaseChange(int PhaseNum)
{
	DrawFlag = 1;
}

void spcNotStarted(int cnt)
{
	pceFontSetPos(64 - 5*7, 25);		pceFontPutStr("�A�ˑ��x����@");
	pceFontSetPos(64 - 5*6, 38);		pceFontPutStr("*PUSH START*");
	pceFontSetPos(128 - 17*5, 78);	pceFontPutStr("By Yui N., 2003.");

	if(pcePadGet() & TRG_C)
	{
		Cls();
		phsChange(emCountingDown);
		CountdownStart = cnt;
		return;
	}
	if(pcePadGet() & TRG_D)
	{
		phsChange(emExit);
		return;
	}

	if(pcePadGet() & TRG_UP)
		if(TrialSeconds < 60)	TrialSeconds += 10;
	if(pcePadGet() & TRG_DN)
		if(TrialSeconds > 10)	TrialSeconds -= 10;

	pceFontSetPos(25, 60);	pceFontPrintf("���莞�ԁF%2d sec.", TrialSeconds);
	DrawFlag = 1;
	Refresh();
}

void spcCountingDown(int cnt)
{
	if(cnt - CountdownStart < 20 * 5)
	{
		Cls();
		pceFontSetPos(64 - 50, 25);	pceFontPutStr("�����޳݂��I�������");
		pceFontSetPos(64 - 45, 35);	pceFontPutStr("�`�{�^����A�ł��I");
		pceFontSetPos(61, 45);
		pceFontPrintf("%d", 5 - (cnt - CountdownStart) / 20);
	}
	else
	{
		Cls();
		phsChange(emStarted);
	}
}

void spcExit(int cnt)
{
	pceFontSetBkColor(FC_SPRITE);
	pceAppReqExit(0);
}

void spcStarted(int cnt)
{
	unsigned long startCount, nowCount, diffCount;
	int pressed = 0;

	KeyCount = 0;	Average = 0;

	startCount = pceTimerGetCount();
	while(((nowCount = pceTimerGetCount()) - startCount) < TrialSeconds * 1000)
	{
		// division by 0 �΍�̂���������
		diffCount = (startCount == nowCount) ? 1 : nowCount - startCount;

		pcePadGetProc();

		if(((pcePadGet() & PAD_A) != 0) && (pressed == 0))
			pressed = 1;
		if(((pcePadGet() & PAD_A) == 0) && (pressed != 0))
		{
			KeyCount++;
			pressed = 0;
		}

		if((pcePadGet() & (PAD_C | PAD_D)) == (PAD_C | PAD_D))
		{
			/* �ً}�E�o */
			phsChange(emExit);
			return;
		}
		if(pcePadGet() & PAD_D)
		{
			Cls();
			phsChange(emNotStarted);
			return;
		}

		// k / d / 1000 = (k/1) / (d/1000) = 1000k / d
		// ������ Zero division �ɂ��čl������K�v��������
		Average = KeyCount * 1000 / diffCount;

		pceFontSetPos(30, 20);
		pceFontPrintf("�c�莞�ԁF%2d sec.", TrialSeconds - diffCount / 1000);
		pceFontSetPos(30, 35);
		pceFontPrintf("�����񐔁F%4d", KeyCount);
		pceFontSetPos(30, 50);
		pceFontPrintf("�A�ˑ��x�F%2d/sec.", Average);

		DrawFlag = 1;
		Refresh();
	}
	phsChange(emSummary);
}

void spcSummary(int cnt)
{
	Cls();

	pceFontSetPos(30, 20);
	pceFontPrintf("���莞�ԁF%2d sec.", TrialSeconds);
	pceFontSetPos(30, 35);
	pceFontPrintf("�����񐔁F%4d", KeyCount);
	pceFontSetPos(30, 50);
	pceFontPrintf("�A�ˑ��x�F%2d/sec.", Average);

	pceFontSetPos(0, 78);
	pceFontPutStr("����: ��ײ; �ڸ�: �I��");

	if(pcePadGet() & TRG_C)
	{
		Cls();
		phsChange(emNotStarted);
	}
	if(pcePadGet() & TRG_D)
		phsChange(emExit);
}

///////////////////////////////////////////////////////////////////////////////

void pceAppInit()
{
	pceLCDDispStop();
	pceLCDSetBuffer(vScreen);
	pceAppSetProcPeriod(50);

	PreparePhaseProcedure();

	pceFontSetBkColor(0);

	phsChange(emNotStarted);

	pceLCDDispStart();
}

void pceAppProc(int cnt)
{
	Refresh();
	phsRunProc(cnt);
}

void pceAppExit()
{
	phsFinalize();
}
